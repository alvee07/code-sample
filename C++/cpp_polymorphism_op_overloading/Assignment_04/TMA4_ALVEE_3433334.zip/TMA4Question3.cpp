//: TMA4Question3.cpp

/*
 Title: TMA4Question3.cpp
 Description:  with C++
 Date: January 30, 2020
 Author: Alvee H. Akash
 ID: 3433334
 Version: 1.0
 Copyright: 2020 Alvee H. Akash
 */


/*
 DOCUMENTATION

 Program Purpose:
 Documentation followed as GoodDocs.cpp,
 test plans are showed in the next paragraph,
 and comments are inline comments for better understanding.
 keyboard input N/A.

 Compile (Assuming GCC compiler istalled): g++ -o TMA4Question3 TMA4Question3.cpp
 Execution (assuming Cygwin is running): ./TMA4Question3

 Notes: in g++, main return type int

 Classes:

 Variables:

 */

/*
 TEST PLAN

 Normal case:
 

 Discussion:

*/
